package com.pdd.pop.sdk.http.api.pop.response;

import com.pdd.pop.ext.fasterxml.jackson.annotation.JsonProperty;
import com.pdd.pop.sdk.http.PopBaseHttpResponse;




public class PddOrderConsolidateOrderUserAddressGetResponse extends PopBaseHttpResponse {

    /**
     * 
     */
    @JsonProperty("response")
    private Response response;

    public Response getResponse() {
        return response;
    }

    public static class Response {

        /**
         * 订单号
         */
        @JsonProperty("order_sn")
        private String orderSn;

        /**
         * 用户实际收货详细地址，不拼接省市区。
         */
        @JsonProperty("user_receiving_address")
        private String userReceivingAddress;

        /**
         * 用户实际收货城市
         */
        @JsonProperty("user_receiving_city")
        private String userReceivingCity;

        /**
         * 用户实际收货城市编码
         */
        @JsonProperty("user_receiving_city_id")
        private Integer userReceivingCityId;

        /**
         * 用户实际收货姓名
         */
        @JsonProperty("user_receiving_name")
        private String userReceivingName;

        /**
         * 用户实际收货手机号
         */
        @JsonProperty("user_receiving_phone")
        private String userReceivingPhone;

        /**
         * 用户实际收货省份
         */
        @JsonProperty("user_receiving_province")
        private String userReceivingProvince;

        /**
         * 用户实际收货省份编码
         */
        @JsonProperty("user_receiving_province_id")
        private Integer userReceivingProvinceId;

        /**
         * 用户实际收货区县
         */
        @JsonProperty("user_receiving_town")
        private String userReceivingTown;

        /**
         * 用户实际收货区县编码
         */
        @JsonProperty("user_receiving_town_id")
        private Integer userReceivingTownId;

        public String getOrderSn() {
            return orderSn;
        }

        public String getUserReceivingAddress() {
            return userReceivingAddress;
        }

        public String getUserReceivingCity() {
            return userReceivingCity;
        }

        public Integer getUserReceivingCityId() {
            return userReceivingCityId;
        }

        public String getUserReceivingName() {
            return userReceivingName;
        }

        public String getUserReceivingPhone() {
            return userReceivingPhone;
        }

        public String getUserReceivingProvince() {
            return userReceivingProvince;
        }

        public Integer getUserReceivingProvinceId() {
            return userReceivingProvinceId;
        }

        public String getUserReceivingTown() {
            return userReceivingTown;
        }

        public Integer getUserReceivingTownId() {
            return userReceivingTownId;
        }
    }
}