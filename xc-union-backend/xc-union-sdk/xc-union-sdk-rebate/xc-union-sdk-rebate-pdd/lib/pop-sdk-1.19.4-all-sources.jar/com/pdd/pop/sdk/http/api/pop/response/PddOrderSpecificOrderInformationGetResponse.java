package com.pdd.pop.sdk.http.api.pop.response;

import com.pdd.pop.ext.fasterxml.jackson.annotation.JsonProperty;
import com.pdd.pop.sdk.http.PopBaseHttpResponse;

import java.util.List;



public class PddOrderSpecificOrderInformationGetResponse extends PopBaseHttpResponse {

    /**
     * response
     */
    @JsonProperty("specific_order_info")
    private SpecificOrderInfo specificOrderInfo;

    public SpecificOrderInfo getSpecificOrderInfo() {
        return specificOrderInfo;
    }

    public static class SpecificOrderInfo {

        /**
         * 售后状态 0：无售后 2：买家申请退款，待商家处理 3：退货退款，待商家处理 4：商家同意退款，退款中 5：平台同意退款，退款中 6：驳回退款，待买家处理 7：已同意退货退款,待用户发货 8：平台处理中 9：平台拒绝退款，退款关闭 10：退款成功 11：买家撤销 12：买家逾期未处理，退款失败 13：买家逾期，超过有效期 14：换货补寄待商家处理 15：换货补寄待用户处理 16：换货补寄成功 17：换货补寄失败 18：换货补寄待用户确认完成 21：待商家同意维修 22：待用户确认发货 24：维修关闭 25：维修成功 27：待用户确认收货 31：已同意拒收退款，待用户拒收 32：补寄待商家发货 33：同意召回后退款，待商家召回
         */
        @JsonProperty("after_sales_status")
        private Integer afterSalesStatus;

        /**
         * 买家留言信息
         */
        @JsonProperty("buyer_memo")
        private String buyerMemo;

        /**
         * 创建时间
         */
        @JsonProperty("created_time")
        private String createdTime;

        /**
         * 分批发货子单信息列表
         */
        @JsonProperty("delivery_schedule_sub_order_list")
        private List<SpecificOrderInfoDeliveryScheduleSubOrderListItem> deliveryScheduleSubOrderList;

        /**
         * 订单中商品sku列表
         */
        @JsonProperty("item_list")
        private List<SpecificOrderInfoItemListItem> itemList;

        /**
         * 订单编号
         */
        @JsonProperty("order_sn")
        private String orderSn;

        /**
         * 发货状态，枚举值：1：待发货，2：已发货待签收，3：已签收
         */
        @JsonProperty("order_status")
        private Integer orderStatus;

        /**
         * 退款状态，枚举值：1：无售后或售后关闭，2：售后处理中，3：退款中，4： 退款成功
         */
        @JsonProperty("refund_status")
        private Integer refundStatus;

        /**
         * 商家订单备注
         */
        @JsonProperty("remark")
        private String remark;

        /**
         * 订单备注标记，1-红色，2-黄色，3-绿色，4-蓝色，5-紫色
         */
        @JsonProperty("remark_tag")
        private Integer remarkTag;

        /**
         * 订单备注标记名称
         */
        @JsonProperty("remark_tag_name")
        private String remarkTagName;

        /**
         * 订单审核状态（0-正常订单， 1-审核中订单）
         */
        @JsonProperty("risk_control_status")
        private Integer riskControlStatus;

        public Integer getAfterSalesStatus() {
            return afterSalesStatus;
        }

        public String getBuyerMemo() {
            return buyerMemo;
        }

        public String getCreatedTime() {
            return createdTime;
        }

        public List<SpecificOrderInfoDeliveryScheduleSubOrderListItem> getDeliveryScheduleSubOrderList() {
            return deliveryScheduleSubOrderList;
        }

        public List<SpecificOrderInfoItemListItem> getItemList() {
            return itemList;
        }

        public String getOrderSn() {
            return orderSn;
        }

        public Integer getOrderStatus() {
            return orderStatus;
        }

        public Integer getRefundStatus() {
            return refundStatus;
        }

        public String getRemark() {
            return remark;
        }

        public Integer getRemarkTag() {
            return remarkTag;
        }

        public String getRemarkTagName() {
            return remarkTagName;
        }

        public Integer getRiskControlStatus() {
            return riskControlStatus;
        }
    }

    public static class SpecificOrderInfoDeliveryScheduleSubOrderListItem {

        /**
         * 收件地城市
         */
        @JsonProperty("city")
        private String city;

        /**
         * 城市编码
         */
        @JsonProperty("city_id")
        private Integer cityId;

        /**
         * 子单商品词条信息
         */
        @JsonProperty("goods_entry_list")
        private List<SpecificOrderInfoDeliveryScheduleSubOrderListItemGoodsEntryListItem> goodsEntryList;

        /**
         * 子单承诺发货时间
         */
        @JsonProperty("last_ship_time")
        private String lastShipTime;

        /**
         * 子单快递公司编号
         */
        @JsonProperty("logistics_id")
        private Integer logisticsId;

        /**
         * 收件地省份
         */
        @JsonProperty("province")
        private String province;

        /**
         * 省份编码
         */
        @JsonProperty("province_id")
        private Integer provinceId;

        /**
         * 收件人地址，不拼接省市区。子单状态为待发货状态，且订单未被风控打标的情况下返回密文数据；其余情况返回空字符串。
         */
        @JsonProperty("receiver_address")
        private String receiverAddress;

        /**
         * 收件人姓名。子单状态为待发货状态，且订单未被风控打标的情况下返回密文数据；其余情况返回空字符串
         */
        @JsonProperty("receiver_name")
        private String receiverName;

        /**
         * 收件人电话。子单状态为待发货状态，且订单未被风控打标的情况下返回密文数据；其余情况返回空字符串。
         */
        @JsonProperty("receiver_phone")
        private String receiverPhone;

        /**
         * 批次
         */
        @JsonProperty("sequence_id")
        private Integer sequenceId;

        /**
         * 子单状态（1-待发货；2-已发货；31-已退款）
         */
        @JsonProperty("sub_order_status")
        private Integer subOrderStatus;

        /**
         * 收件地区县
         */
        @JsonProperty("town")
        private String town;

        /**
         * 区县编码
         */
        @JsonProperty("town_id")
        private Integer townId;

        /**
         * 子单快递运单号
         */
        @JsonProperty("tracking_number")
        private String trackingNumber;

        public String getCity() {
            return city;
        }

        public Integer getCityId() {
            return cityId;
        }

        public List<SpecificOrderInfoDeliveryScheduleSubOrderListItemGoodsEntryListItem> getGoodsEntryList() {
            return goodsEntryList;
        }

        public String getLastShipTime() {
            return lastShipTime;
        }

        public Integer getLogisticsId() {
            return logisticsId;
        }

        public String getProvince() {
            return province;
        }

        public Integer getProvinceId() {
            return provinceId;
        }

        public String getReceiverAddress() {
            return receiverAddress;
        }

        public String getReceiverName() {
            return receiverName;
        }

        public String getReceiverPhone() {
            return receiverPhone;
        }

        public Integer getSequenceId() {
            return sequenceId;
        }

        public Integer getSubOrderStatus() {
            return subOrderStatus;
        }

        public String getTown() {
            return town;
        }

        public Integer getTownId() {
            return townId;
        }

        public String getTrackingNumber() {
            return trackingNumber;
        }
    }

    public static class SpecificOrderInfoDeliveryScheduleSubOrderListItemGoodsEntryListItem {

        /**
         * 词条名称
         */
        @JsonProperty("name")
        private String name;

        public String getName() {
            return name;
        }
    }

    public static class SpecificOrderInfoItemListItem {

        /**
         * 商品数量
         */
        @JsonProperty("goods_count")
        private Integer goodsCount;

        /**
         * 商品编号
         */
        @JsonProperty("goods_id")
        private Long goodsId;

        /**
         * 商品图片
         */
        @JsonProperty("goods_img")
        private String goodsImg;

        /**
         * 商品名称
         */
        @JsonProperty("goods_name")
        private String goodsName;

        /**
         * 商品销售价格
         */
        @JsonProperty("goods_price")
        private Double goodsPrice;

        /**
         * 商品规格，使用（规格值1,规格值2）组合作为sku的表示，中间以英文逗号隔开
         */
        @JsonProperty("goods_spec")
        private String goodsSpec;

        /**
         * 商家外部编码（商品），注意：编辑商品后必须等待商品审核通过后方可生效，订单中商品信息为交易快照的商品信息。
         */
        @JsonProperty("outer_goods_id")
        private String outerGoodsId;

        /**
         * 商家外部sku编码
         */
        @JsonProperty("outer_id")
        private String outerId;

        /**
         * 商品规格编码
         */
        @JsonProperty("sku_id")
        private Long skuId;

        public Integer getGoodsCount() {
            return goodsCount;
        }

        public Long getGoodsId() {
            return goodsId;
        }

        public String getGoodsImg() {
            return goodsImg;
        }

        public String getGoodsName() {
            return goodsName;
        }

        public Double getGoodsPrice() {
            return goodsPrice;
        }

        public String getGoodsSpec() {
            return goodsSpec;
        }

        public String getOuterGoodsId() {
            return outerGoodsId;
        }

        public String getOuterId() {
            return outerId;
        }

        public Long getSkuId() {
            return skuId;
        }
    }
}