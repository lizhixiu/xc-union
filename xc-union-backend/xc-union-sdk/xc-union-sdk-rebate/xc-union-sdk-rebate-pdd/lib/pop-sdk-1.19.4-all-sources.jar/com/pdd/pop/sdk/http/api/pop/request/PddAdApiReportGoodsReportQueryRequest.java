package com.pdd.pop.sdk.http.api.pop.request;

import com.pdd.pop.ext.fasterxml.jackson.annotation.JsonProperty;
import com.pdd.pop.sdk.http.api.pop.response.PddAdApiReportGoodsReportQueryResponse;
import com.pdd.pop.sdk.http.HttpMethod;
import com.pdd.pop.sdk.http.PopBaseHttpRequest;

import java.util.List;
import java.util.Map;

public class PddAdApiReportGoodsReportQueryRequest extends PopBaseHttpRequest<PddAdApiReportGoodsReportQueryResponse> {

    /**
     * 结束日期的字符串，格式类似'2020-02-02'
     */
    @JsonProperty("endDateString")
    private String endDateString;

    /**
     * 指定查询的商品id列表, 最多100个
     */
    @JsonProperty("goodsIdList")
    private List<Long> goodsIdList;

    /**
     * 商品推广场景 1-标准推广、2-全站推广-稳定成本、3-全站推广-全店托管、4-全站推广-抢量神器、5-商品推广-稳定成本、6-商品推广-全店托管、7-商品推广-抢量神器
     */
    @JsonProperty("promotionScene")
    private Integer promotionScene;

    /**
     * 开始日期的字符串，格式类似'2020-02-02'，如果查询今日，startDateString和endDateString传今日的字符串，如果查询历史，startDateString和endDateString分别传开始和结束字符串，不能跨今日和历史查询，当前支持查询90天内数据。
     */
    @JsonProperty("startDateString")
    private String startDateString;

    @Override
    public String getVersion() {
        return "V1";
    }

    @Override
    public String getDataType() {
        return "JSON";
    }

    @Override
    public Integer getPlatform() {
        return 0;
    }

    @Override
    public String getType() {
        return "pdd.ad.api.report.goods.report.query";
    }

    @Override
    public HttpMethod getHttpMethod() {
        return HttpMethod.POST;
    }

    @Override
    public Class<PddAdApiReportGoodsReportQueryResponse> getResponseClass() {
        return PddAdApiReportGoodsReportQueryResponse.class;
    }

    @Override
    protected void setUserParams(Map<String, String> params) {
        setUserParam(params, "endDateString", endDateString);
        setUserParam(params, "goodsIdList", goodsIdList);
        setUserParam(params, "promotionScene", promotionScene);
        setUserParam(params, "startDateString", startDateString);
    }

    public void setEndDateString(String endDateString) {
        this.endDateString = endDateString;
    }

    public void setGoodsIdList(List<Long> goodsIdList) {
        this.goodsIdList = goodsIdList;
    }

    public void setPromotionScene(Integer promotionScene) {
        this.promotionScene = promotionScene;
    }

    public void setStartDateString(String startDateString) {
        this.startDateString = startDateString;
    }
}