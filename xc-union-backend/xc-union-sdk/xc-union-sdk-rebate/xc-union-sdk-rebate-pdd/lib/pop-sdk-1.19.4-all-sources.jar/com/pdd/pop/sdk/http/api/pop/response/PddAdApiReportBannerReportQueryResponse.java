package com.pdd.pop.sdk.http.api.pop.response;

import com.pdd.pop.ext.fasterxml.jackson.annotation.JsonProperty;
import com.pdd.pop.sdk.http.PopBaseHttpResponse;

import java.util.List;



public class PddAdApiReportBannerReportQueryResponse extends PopBaseHttpResponse {

    /**
     * 
     */
    @JsonProperty("response")
    private Response response;

    public Response getResponse() {
        return response;
    }

    public static class Response {

        /**
         * 
         */
        @JsonProperty("errorCode")
        private Integer errorCode;

        /**
         * 
         */
        @JsonProperty("errorMsg")
        private String errorMsg;

        /**
         * 
         */
        @JsonProperty("result")
        private ResponseResult result;

        /**
         * 
         */
        @JsonProperty("success")
        private Boolean success;

        public Integer getErrorCode() {
            return errorCode;
        }

        public String getErrorMsg() {
            return errorMsg;
        }

        public ResponseResult getResult() {
            return result;
        }

        public Boolean getSuccess() {
            return success;
        }
    }

    public static class ResponseResult {

        /**
         * 
         */
        @JsonProperty("dailyReportList")
        private List<ResponseResultDailyReportListItem> dailyReportList;

        public List<ResponseResultDailyReportListItem> getDailyReportList() {
            return dailyReportList;
        }
    }

    public static class ResponseResultDailyReportListItem {

        /**
         * 日期
         */
        @JsonProperty("date")
        private String date;

        /**
         * 花费
         */
        @JsonProperty("spend")
        private Long spend;

        public String getDate() {
            return date;
        }

        public Long getSpend() {
            return spend;
        }
    }
}