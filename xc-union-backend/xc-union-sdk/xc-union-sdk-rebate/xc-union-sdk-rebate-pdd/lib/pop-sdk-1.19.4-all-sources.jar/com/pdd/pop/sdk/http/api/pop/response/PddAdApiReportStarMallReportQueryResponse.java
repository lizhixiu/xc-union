package com.pdd.pop.sdk.http.api.pop.response;

import com.pdd.pop.ext.fasterxml.jackson.annotation.JsonProperty;
import com.pdd.pop.sdk.http.PopBaseHttpResponse;

import java.util.List;



public class PddAdApiReportStarMallReportQueryResponse extends PopBaseHttpResponse {

    /**
     * 
     */
    @JsonProperty("response")
    private Response response;

    public Response getResponse() {
        return response;
    }

    public static class Response {

        /**
         * 
         */
        @JsonProperty("errorCode")
        private Integer errorCode;

        /**
         * 
         */
        @JsonProperty("errorMsg")
        private String errorMsg;

        /**
         * 
         */
        @JsonProperty("result")
        private ResponseResult result;

        /**
         * 
         */
        @JsonProperty("success")
        private Boolean success;

        public Integer getErrorCode() {
            return errorCode;
        }

        public String getErrorMsg() {
            return errorMsg;
        }

        public ResponseResult getResult() {
            return result;
        }

        public Boolean getSuccess() {
            return success;
        }
    }

    public static class ResponseResult {

        /**
         * 
         */
        @JsonProperty("dailyReportList")
        private List<ResponseResultDailyReportListItem> dailyReportList;

        /**
         * 推广品牌词维度报表列表
         */
        @JsonProperty("promotionBrandReport")
        private ResponseResultPromotionBrandReport promotionBrandReport;

        public List<ResponseResultDailyReportListItem> getDailyReportList() {
            return dailyReportList;
        }

        public ResponseResultPromotionBrandReport getPromotionBrandReport() {
            return promotionBrandReport;
        }
    }

    public static class ResponseResultDailyReportListItem {

        /**
         * 每笔成交金额，单位厘
         */
        @JsonProperty("avgPayAmount")
        private Double avgPayAmount;

        /**
         * 点击量
         */
        @JsonProperty("click")
        private Long click;

        /**
         * 千次曝光花费，单位厘
         */
        @JsonProperty("cpm")
        private Double cpm;

        /**
         * 点击率
         */
        @JsonProperty("ctr")
        private Double ctr;

        /**
         * 点击转化率
         */
        @JsonProperty("cvr")
        private Double cvr;

        /**
         * 日期
         */
        @JsonProperty("date")
        private String date;

        /**
         * 交易额，单位厘
         */
        @JsonProperty("gmv")
        private Long gmv;

        /**
         * 商品收藏量
         */
        @JsonProperty("goodsFavNum")
        private Long goodsFavNum;

        /**
         * 曝光量
         */
        @JsonProperty("impression")
        private Long impression;

        /**
         * 店铺关注量
         */
        @JsonProperty("mallFavNum")
        private Long mallFavNum;

        /**
         * 成交笔数
         */
        @JsonProperty("orderNum")
        private Long orderNum;

        /**
         * 投入产出比，万分比
         */
        @JsonProperty("roi")
        private Double roi;

        /**
         * 花费，单位厘
         */
        @JsonProperty("spend")
        private Long spend;

        /**
         * 每笔成交花费，单位厘
         */
        @JsonProperty("transactionCost")
        private Double transactionCost;

        public Double getAvgPayAmount() {
            return avgPayAmount;
        }

        public Long getClick() {
            return click;
        }

        public Double getCpm() {
            return cpm;
        }

        public Double getCtr() {
            return ctr;
        }

        public Double getCvr() {
            return cvr;
        }

        public String getDate() {
            return date;
        }

        public Long getGmv() {
            return gmv;
        }

        public Long getGoodsFavNum() {
            return goodsFavNum;
        }

        public Long getImpression() {
            return impression;
        }

        public Long getMallFavNum() {
            return mallFavNum;
        }

        public Long getOrderNum() {
            return orderNum;
        }

        public Double getRoi() {
            return roi;
        }

        public Long getSpend() {
            return spend;
        }

        public Double getTransactionCost() {
            return transactionCost;
        }
    }

    public static class ResponseResultPromotionBrandReport {

        /**
         * 推广品牌词维度报表列表
         */
        @JsonProperty("promotionBrandReportItemList")
        private List<ResponseResultPromotionBrandReportPromotionBrandReportItemListItem> promotionBrandReportItemList;

        /**
         * 总数
         */
        @JsonProperty("total")
        private Long total;

        public List<ResponseResultPromotionBrandReportPromotionBrandReportItemListItem> getPromotionBrandReportItemList() {
            return promotionBrandReportItemList;
        }

        public Long getTotal() {
            return total;
        }
    }

    public static class ResponseResultPromotionBrandReportPromotionBrandReportItemListItem {

        /**
         * 推广ID
         */
        @JsonProperty("adId")
        private Long adId;

        /**
         * 推广名称
         */
        @JsonProperty("adName")
        private String adName;

        /**
         * 每笔成交金额，单位厘
         */
        @JsonProperty("avgPayAmount")
        private Double avgPayAmount;

        /**
         * 品牌名称
         */
        @JsonProperty("brandName")
        private String brandName;

        /**
         * 点击量
         */
        @JsonProperty("click")
        private Long click;

        /**
         * 千次曝光花费，单位厘
         */
        @JsonProperty("cpm")
        private Double cpm;

        /**
         * 点击率
         */
        @JsonProperty("ctr")
        private Double ctr;

        /**
         * 点击转化率
         */
        @JsonProperty("cvr")
        private Double cvr;

        /**
         * 交易额，单位厘
         */
        @JsonProperty("gmv")
        private Long gmv;

        /**
         * 商品收藏量
         */
        @JsonProperty("goodsFavNum")
        private Long goodsFavNum;

        /**
         * 曝光量
         */
        @JsonProperty("impression")
        private Long impression;

        /**
         * 店铺关注量
         */
        @JsonProperty("mallFavNum")
        private Long mallFavNum;

        /**
         * 成交笔数
         */
        @JsonProperty("orderNum")
        private Long orderNum;

        /**
         * 投入产出比，万分比
         */
        @JsonProperty("roi")
        private Double roi;

        /**
         * 花费，单位厘
         */
        @JsonProperty("spend")
        private Long spend;

        /**
         * 每笔成交花费，单位厘
         */
        @JsonProperty("transactionCost")
        private Double transactionCost;

        public Long getAdId() {
            return adId;
        }

        public String getAdName() {
            return adName;
        }

        public Double getAvgPayAmount() {
            return avgPayAmount;
        }

        public String getBrandName() {
            return brandName;
        }

        public Long getClick() {
            return click;
        }

        public Double getCpm() {
            return cpm;
        }

        public Double getCtr() {
            return ctr;
        }

        public Double getCvr() {
            return cvr;
        }

        public Long getGmv() {
            return gmv;
        }

        public Long getGoodsFavNum() {
            return goodsFavNum;
        }

        public Long getImpression() {
            return impression;
        }

        public Long getMallFavNum() {
            return mallFavNum;
        }

        public Long getOrderNum() {
            return orderNum;
        }

        public Double getRoi() {
            return roi;
        }

        public Long getSpend() {
            return spend;
        }

        public Double getTransactionCost() {
            return transactionCost;
        }
    }
}