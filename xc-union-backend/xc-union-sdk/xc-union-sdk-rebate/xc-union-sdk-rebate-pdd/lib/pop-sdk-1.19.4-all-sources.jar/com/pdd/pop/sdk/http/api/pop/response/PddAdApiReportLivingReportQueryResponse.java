package com.pdd.pop.sdk.http.api.pop.response;

import com.pdd.pop.ext.fasterxml.jackson.annotation.JsonProperty;
import com.pdd.pop.sdk.http.PopBaseHttpResponse;

import java.util.List;



public class PddAdApiReportLivingReportQueryResponse extends PopBaseHttpResponse {

    /**
     * 
     */
    @JsonProperty("response")
    private Response response;

    public Response getResponse() {
        return response;
    }

    public static class Response {

        /**
         * 
         */
        @JsonProperty("errorCode")
        private Integer errorCode;

        /**
         * 
         */
        @JsonProperty("errorMsg")
        private String errorMsg;

        /**
         * 
         */
        @JsonProperty("result")
        private ResponseResult result;

        /**
         * 
         */
        @JsonProperty("success")
        private Boolean success;

        public Integer getErrorCode() {
            return errorCode;
        }

        public String getErrorMsg() {
            return errorMsg;
        }

        public ResponseResult getResult() {
            return result;
        }

        public Boolean getSuccess() {
            return success;
        }
    }

    public static class ResponseResult {

        /**
         * 
         */
        @JsonProperty("dailyReportList")
        private List<ResponseResultDailyReportListItem> dailyReportList;

        public List<ResponseResultDailyReportListItem> getDailyReportList() {
            return dailyReportList;
        }
    }

    public static class ResponseResultDailyReportListItem {

        /**
         * 每笔成交金额，单位厘
         */
        @JsonProperty("avgPayAmount")
        private Double avgPayAmount;

        /**
         * 千次曝光花费，单位厘
         */
        @JsonProperty("cpm")
        private Double cpm;

        /**
         * 日期
         */
        @JsonProperty("date")
        private String date;

        /**
         * 交易额，单位厘
         */
        @JsonProperty("gmv")
        private Long gmv;

        /**
         * 商品收藏量
         */
        @JsonProperty("goodsFavNum")
        private Long goodsFavNum;

        /**
         * 千次曝光交易额，单位厘
         */
        @JsonProperty("gpm")
        private Double gpm;

        /**
         * 曝光量
         */
        @JsonProperty("impression")
        private Long impression;

        /**
         * 直播评论量
         */
        @JsonProperty("liveCommentNum")
        private Long liveCommentNum;

        /**
         * 每笔成交花费，单位厘
         */
        @JsonProperty("liveCostPerOrder")
        private Double liveCostPerOrder;

        /**
         * 千次曝光增粉数
         */
        @JsonProperty("liveFavRate")
        private Double liveFavRate;

        /**
         * 深度观看
         */
        @JsonProperty("liveLongRetention")
        private Long liveLongRetention;

        /**
         * 成交花费，单位厘
         */
        @JsonProperty("livePaySpend")
        private Long livePaySpend;

        /**
         * 千次曝光转化数
         */
        @JsonProperty("opm")
        private Double opm;

        /**
         * 成交笔数
         */
        @JsonProperty("orderNum")
        private Long orderNum;

        /**
         * 投入产出比，万分比
         */
        @JsonProperty("roi")
        private Double roi;

        /**
         * 花费，单位厘
         */
        @JsonProperty("spend")
        private Long spend;

        /**
         * 关注量
         */
        @JsonProperty("totalFav")
        private Long totalFav;

        public Double getAvgPayAmount() {
            return avgPayAmount;
        }

        public Double getCpm() {
            return cpm;
        }

        public String getDate() {
            return date;
        }

        public Long getGmv() {
            return gmv;
        }

        public Long getGoodsFavNum() {
            return goodsFavNum;
        }

        public Double getGpm() {
            return gpm;
        }

        public Long getImpression() {
            return impression;
        }

        public Long getLiveCommentNum() {
            return liveCommentNum;
        }

        public Double getLiveCostPerOrder() {
            return liveCostPerOrder;
        }

        public Double getLiveFavRate() {
            return liveFavRate;
        }

        public Long getLiveLongRetention() {
            return liveLongRetention;
        }

        public Long getLivePaySpend() {
            return livePaySpend;
        }

        public Double getOpm() {
            return opm;
        }

        public Long getOrderNum() {
            return orderNum;
        }

        public Double getRoi() {
            return roi;
        }

        public Long getSpend() {
            return spend;
        }

        public Long getTotalFav() {
            return totalFav;
        }
    }
}