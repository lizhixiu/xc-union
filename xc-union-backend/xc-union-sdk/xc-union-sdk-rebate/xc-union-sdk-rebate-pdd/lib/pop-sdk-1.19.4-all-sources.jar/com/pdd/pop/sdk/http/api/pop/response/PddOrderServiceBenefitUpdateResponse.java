package com.pdd.pop.sdk.http.api.pop.response;

import com.pdd.pop.ext.fasterxml.jackson.annotation.JsonProperty;
import com.pdd.pop.sdk.http.PopBaseHttpResponse;




public class PddOrderServiceBenefitUpdateResponse extends PopBaseHttpResponse {

    /**
     * 
     */
    @JsonProperty("service_benefit_update_response")
    private ServiceBenefitUpdateResponse serviceBenefitUpdateResponse;

    public ServiceBenefitUpdateResponse getServiceBenefitUpdateResponse() {
        return serviceBenefitUpdateResponse;
    }

    public static class ServiceBenefitUpdateResponse {

        /**
         * 更新成功:true；更新失败:false
         */
        @JsonProperty("success")
        private Boolean success;

        public Boolean getSuccess() {
            return success;
        }
    }
}