package com.pdd.pop.sdk.http.api.pop.response;

import com.pdd.pop.ext.fasterxml.jackson.annotation.JsonProperty;
import com.pdd.pop.sdk.http.PopBaseHttpResponse;

import java.util.List;



public class PddAdApiReportGoodsReportQueryResponse extends PopBaseHttpResponse {

    /**
     * 
     */
    @JsonProperty("response")
    private Response response;

    public Response getResponse() {
        return response;
    }

    public static class Response {

        /**
         * 
         */
        @JsonProperty("errorCode")
        private Integer errorCode;

        /**
         * 
         */
        @JsonProperty("errorMsg")
        private String errorMsg;

        /**
         * 
         */
        @JsonProperty("result")
        private ResponseResult result;

        /**
         * 
         */
        @JsonProperty("success")
        private Boolean success;

        public Integer getErrorCode() {
            return errorCode;
        }

        public String getErrorMsg() {
            return errorMsg;
        }

        public ResponseResult getResult() {
            return result;
        }

        public Boolean getSuccess() {
            return success;
        }
    }

    public static class ResponseResult {

        /**
         * 天级店铺维度报表
         */
        @JsonProperty("dailyReportList")
        private List<ResponseResultDailyReportListItem> dailyReportList;

        /**
         * 商品维度报表
         */
        @JsonProperty("goodsReportList")
        private List<ResponseResultGoodsReportListItem> goodsReportList;

        public List<ResponseResultDailyReportListItem> getDailyReportList() {
            return dailyReportList;
        }

        public List<ResponseResultGoodsReportListItem> getGoodsReportList() {
            return goodsReportList;
        }
    }

    public static class ResponseResultDailyReportListItem {

        /**
         * 每笔成交金额，单位厘
         */
        @JsonProperty("avgPayAmount")
        private Double avgPayAmount;

        /**
         * 点击量
         */
        @JsonProperty("click")
        private Long click;

        /**
         * 点击率
         */
        @JsonProperty("ctr")
        private Double ctr;

        /**
         * 点击转化率
         */
        @JsonProperty("cvr")
        private Double cvr;

        /**
         * 日期
         */
        @JsonProperty("date")
        private String date;

        /**
         * 全站推广费比
         */
        @JsonProperty("globalTakeRate")
        private Double globalTakeRate;

        /**
         * 交易额，单位厘
         */
        @JsonProperty("gmv")
        private Long gmv;

        /**
         * 曝光量
         */
        @JsonProperty("impression")
        private Long impression;

        /**
         * 成交笔数
         */
        @JsonProperty("orderNum")
        private Long orderNum;

        /**
         * 成交花费，单位厘
         */
        @JsonProperty("orderSpend")
        private Long orderSpend;

        /**
         * 投入产出比，万分比
         */
        @JsonProperty("roi")
        private Double roi;

        /**
         * 花费，单位厘
         */
        @JsonProperty("spend")
        private Long spend;

        /**
         * 每笔成交花费，单位厘
         */
        @JsonProperty("transactionCost")
        private Double transactionCost;

        public Double getAvgPayAmount() {
            return avgPayAmount;
        }

        public Long getClick() {
            return click;
        }

        public Double getCtr() {
            return ctr;
        }

        public Double getCvr() {
            return cvr;
        }

        public String getDate() {
            return date;
        }

        public Double getGlobalTakeRate() {
            return globalTakeRate;
        }

        public Long getGmv() {
            return gmv;
        }

        public Long getImpression() {
            return impression;
        }

        public Long getOrderNum() {
            return orderNum;
        }

        public Long getOrderSpend() {
            return orderSpend;
        }

        public Double getRoi() {
            return roi;
        }

        public Long getSpend() {
            return spend;
        }

        public Double getTransactionCost() {
            return transactionCost;
        }
    }

    public static class ResponseResultGoodsReportListItem {

        /**
         * 每笔直接成交金额，单位厘
         */
        @JsonProperty("avgDirectPayAmount")
        private Double avgDirectPayAmount;

        /**
         * 每笔间接成交金额，单位厘
         */
        @JsonProperty("avgIndirectPayAmount")
        private Double avgIndirectPayAmount;

        /**
         * 每笔成交金额，单位厘
         */
        @JsonProperty("avgPayAmount")
        private Double avgPayAmount;

        /**
         * 推广曝光量
         */
        @JsonProperty("billingImpression")
        private Long billingImpression;

        /**
         * 点击量
         */
        @JsonProperty("click")
        private Long click;

        /**
         * 平均点击花费，单位厘
         */
        @JsonProperty("cpc")
        private Double cpc;

        /**
         * 点击率
         */
        @JsonProperty("ctr")
        private Double ctr;

        /**
         * 点击转化率
         */
        @JsonProperty("cvr")
        private Double cvr;

        /**
         * 直接交易额，单位厘
         */
        @JsonProperty("directGmv")
        private Long directGmv;

        /**
         * 直接成交笔数
         */
        @JsonProperty("directOrderNum")
        private Long directOrderNum;

        /**
         * 全站推广费比
         */
        @JsonProperty("globalTakeRate")
        private Double globalTakeRate;

        /**
         * 交易额，单位厘
         */
        @JsonProperty("gmv")
        private Long gmv;

        /**
         * 收藏花费，单位厘
         */
        @JsonProperty("goodsFavSpend")
        private Long goodsFavSpend;

        /**
         * 商品id
         */
        @JsonProperty("goodsId")
        private Long goodsId;

        /**
         * 曝光量
         */
        @JsonProperty("impression")
        private Long impression;

        /**
         * 间接交易额，单位厘
         */
        @JsonProperty("indirectGmv")
        private Long indirectGmv;

        /**
         * 间接成交笔数
         */
        @JsonProperty("indirectOrderNum")
        private Long indirectOrderNum;

        /**
         * 询单花费，单位厘
         */
        @JsonProperty("inquirySpend")
        private Long inquirySpend;

        /**
         * 关注花费，单位厘
         */
        @JsonProperty("mallFavSpend")
        private Long mallFavSpend;

        /**
         * 平均收藏成本，单位厘
         */
        @JsonProperty("multiGoalCostPerGoodsFav")
        private Double multiGoalCostPerGoodsFav;

        /**
         * 平均询单成本，单位厘
         */
        @JsonProperty("multiGoalCostPerInquiry")
        private Double multiGoalCostPerInquiry;

        /**
         * 平均关注成本，单位厘
         */
        @JsonProperty("multiGoalCostPerMallFav")
        private Double multiGoalCostPerMallFav;

        /**
         * 收藏量
         */
        @JsonProperty("multiGoalGoodsFavNum")
        private Long multiGoalGoodsFavNum;

        /**
         * 询单量
         */
        @JsonProperty("multiGoalInquiryNum")
        private Long multiGoalInquiryNum;

        /**
         * 关注量
         */
        @JsonProperty("multiGoalMallFavNum")
        private Long multiGoalMallFavNum;

        /**
         * 成交笔数
         */
        @JsonProperty("orderNum")
        private Long orderNum;

        /**
         * 成交花费，单位厘
         */
        @JsonProperty("orderSpend")
        private Long orderSpend;

        /**
         * 投入产出比，万分比
         */
        @JsonProperty("roi")
        private Double roi;

        /**
         * 花费，单位厘
         */
        @JsonProperty("spend")
        private Long spend;

        /**
         * 每笔成交花费，单位厘
         */
        @JsonProperty("transactionCost")
        private Double transactionCost;

        public Double getAvgDirectPayAmount() {
            return avgDirectPayAmount;
        }

        public Double getAvgIndirectPayAmount() {
            return avgIndirectPayAmount;
        }

        public Double getAvgPayAmount() {
            return avgPayAmount;
        }

        public Long getBillingImpression() {
            return billingImpression;
        }

        public Long getClick() {
            return click;
        }

        public Double getCpc() {
            return cpc;
        }

        public Double getCtr() {
            return ctr;
        }

        public Double getCvr() {
            return cvr;
        }

        public Long getDirectGmv() {
            return directGmv;
        }

        public Long getDirectOrderNum() {
            return directOrderNum;
        }

        public Double getGlobalTakeRate() {
            return globalTakeRate;
        }

        public Long getGmv() {
            return gmv;
        }

        public Long getGoodsFavSpend() {
            return goodsFavSpend;
        }

        public Long getGoodsId() {
            return goodsId;
        }

        public Long getImpression() {
            return impression;
        }

        public Long getIndirectGmv() {
            return indirectGmv;
        }

        public Long getIndirectOrderNum() {
            return indirectOrderNum;
        }

        public Long getInquirySpend() {
            return inquirySpend;
        }

        public Long getMallFavSpend() {
            return mallFavSpend;
        }

        public Double getMultiGoalCostPerGoodsFav() {
            return multiGoalCostPerGoodsFav;
        }

        public Double getMultiGoalCostPerInquiry() {
            return multiGoalCostPerInquiry;
        }

        public Double getMultiGoalCostPerMallFav() {
            return multiGoalCostPerMallFav;
        }

        public Long getMultiGoalGoodsFavNum() {
            return multiGoalGoodsFavNum;
        }

        public Long getMultiGoalInquiryNum() {
            return multiGoalInquiryNum;
        }

        public Long getMultiGoalMallFavNum() {
            return multiGoalMallFavNum;
        }

        public Long getOrderNum() {
            return orderNum;
        }

        public Long getOrderSpend() {
            return orderSpend;
        }

        public Double getRoi() {
            return roi;
        }

        public Long getSpend() {
            return spend;
        }

        public Double getTransactionCost() {
            return transactionCost;
        }
    }
}