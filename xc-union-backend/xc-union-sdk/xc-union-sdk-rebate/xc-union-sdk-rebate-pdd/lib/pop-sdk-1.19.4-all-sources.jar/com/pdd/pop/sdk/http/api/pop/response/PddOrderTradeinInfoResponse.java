package com.pdd.pop.sdk.http.api.pop.response;

import com.pdd.pop.ext.fasterxml.jackson.annotation.JsonProperty;
import com.pdd.pop.sdk.http.PopBaseHttpResponse;


import java.util.Map;


public class PddOrderTradeinInfoResponse extends PopBaseHttpResponse {

    /**
     * 
     */
    @JsonProperty("response")
    private Response response;

    public Response getResponse() {
        return response;
    }

    public static class Response {

        /**
         * 
         */
        @JsonProperty("error_code")
        private Integer errorCode;

        /**
         * 
         */
        @JsonProperty("error_msg")
        private String errorMsg;

        /**
         * 
         */
        @JsonProperty("result")
        private ResponseResult result;

        /**
         * 
         */
        @JsonProperty("success")
        private Boolean success;

        public Integer getErrorCode() {
            return errorCode;
        }

        public String getErrorMsg() {
            return errorMsg;
        }

        public ResponseResult getResult() {
            return result;
        }

        public Boolean getSuccess() {
            return success;
        }
    }

    public static class ResponseResult {

        /**
         * 
         */
        @JsonProperty("order_activity_info_map")
        private Map<String, ResponseResultOrderActivityInfoMapValue> orderActivityInfoMap;

        public Map<String, ResponseResultOrderActivityInfoMapValue> getOrderActivityInfoMap() {
            return orderActivityInfoMap;
        }
    }

    public static class ResponseResultOrderActivityInfoMapValue {

        /**
         * 补贴政府区信息
         */
        @JsonProperty("sponsor_city_name")
        private String sponsorCityName;

        /**
         * 补贴政府城市信息
         */
        @JsonProperty("sponsor_district_name")
        private String sponsorDistrictName;

        /**
         * 补贴政府省份信息
         */
        @JsonProperty("sponsor_province_name")
        private String sponsorProvinceName;

        /**
         * 补贴是否生效
         */
        @JsonProperty("subsidy_effective")
        private Boolean subsidyEffective;

        public String getSponsorCityName() {
            return sponsorCityName;
        }

        public String getSponsorDistrictName() {
            return sponsorDistrictName;
        }

        public String getSponsorProvinceName() {
            return sponsorProvinceName;
        }

        public Boolean getSubsidyEffective() {
            return subsidyEffective;
        }
    }
}